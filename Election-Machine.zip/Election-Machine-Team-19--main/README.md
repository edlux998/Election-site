Team members: Edgar Luks, Vjatšeslav Semjonov, Mark Petrov

Scrum (Server programming): https://docs.google.com/spreadsheets/d/1EPOgKsJzAFIK61o6Ag0LTe64R9SUspPWWakftZANHsM/edit#gid=56636606

Scrum (Web Services):https://docs.google.com/spreadsheets/d/1UIH5QpAjVA2Ml7nJscrIlbVBHfDs5Yh_o2-vvryQFyw/edit#gid=56636606

Credentials for Admin Log In:

username: slava

password: password

Responsibility areas:

Vjatšeslav Semjonov - Everything related to tables which show information about candidates from database + most of the CSS ( header, footer, home page, tables )

Mark Petrov - All admin features + CSS on those feautures

Edgar Luks - Questions part ( find best candidate and compare answers ) + CSS on this part
